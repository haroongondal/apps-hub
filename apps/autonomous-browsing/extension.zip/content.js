(() => {
  // Re-injection cannot replace a script already running in the tab.
  if (window.__oaVersion) return;
  window.__oaVersion = chrome.runtime.getManifest().version;

  const SENSITIVE = [
    ['input[type="password"]', 'password field'],
    ['input[autocomplete^="cc-"]', 'payment field'],
    ['input[autocomplete="one-time-code"]', 'one-time code'],
    ['iframe[src*="recaptcha"]', 'CAPTCHA'],
    ['iframe[src*="hcaptcha"]', 'CAPTCHA'],
    ['iframe[src*="challenges.cloudflare.com"]', 'CAPTCHA'],
    ['.g-recaptcha', 'CAPTCHA'],
    ['#cf-turnstile', 'CAPTCHA']
  ];

  const SENSITIVE_TARGET = [
    ['input[type="password"]', 'a password field'],
    ['input[autocomplete^="cc-"]', 'a payment field'],
    ['input[autocomplete="one-time-code"]', 'a one-time-code field']
  ];

  const COMMIT_WORDS =
    /\b(submit|order|pay|paying|buy|purchase|checkout|confirm|delete|remove|send|book|place|transfer|withdraw|publish)\b/;

  const DEFAULT_TIMEOUT = 10000;
  const POLL_MS = 100;
  const SETTLE_MS = 750;

  const host = document.createElement('div');
  host.style.cssText = 'position:fixed;bottom:16px;right:16px;z-index:2147483647;pointer-events:none;';

  const shadow = host.attachShadow({ mode: 'closed' });
  const style = document.createElement('style');
  style.textContent = `
    .banner{display:flex;align-items:center;gap:10px;background:#1c1c1e;color:#f5f5f7;
      font:13px -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;padding:10px 14px;
      border-radius:10px;box-shadow:0 4px 16px rgba(0,0,0,.35);opacity:0;
      transform:translateY(8px);transition:opacity .2s,transform .2s;pointer-events:none}
    .banner.visible{opacity:1;transform:translateY(0);pointer-events:auto}
    .dot{width:8px;height:8px;border-radius:50%;background:#30d158;flex-shrink:0;animation:pulse 1.4s infinite}
    .banner.paused .dot{background:#ff9f0a;animation:none}
    .msg{white-space:nowrap}
    @keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}
    @media (prefers-reduced-motion:reduce){.dot{animation:none}.banner{transition:none}}
    button{border:0;border-radius:6px;padding:5px 10px;font:inherit;font-weight:600;
      cursor:pointer;background:#ff453a;color:#fff}
    button.resume{background:#30d158;color:#04210c}
  `;

  const banner = document.createElement('div');
  banner.className = 'banner';
  banner.setAttribute('role', 'status');
  banner.setAttribute('aria-live', 'polite');

  const dot = document.createElement('span');
  dot.className = 'dot';
  const label = document.createElement('span');
  label.className = 'msg';
  const btn = document.createElement('button');

  banner.append(dot, label, btn);
  shadow.append(style, banner);
  document.documentElement.append(host);

  function render({ state, reason }) {
    const showing = state === 'active' || state === 'paused';
    banner.classList.toggle('visible', showing);
    if (!showing) return;

    const paused = state === 'paused';
    banner.classList.toggle('paused', paused);
    if (paused) label.textContent = reason ? `Paused — ${reason}` : 'Automation paused';
    else label.textContent = 'Automation running…';
    btn.textContent = paused ? 'Resume' : 'Pause Script';
    btn.className = paused ? 'resume' : '';
  }

  btn.addEventListener('click', () => {
    const paused = banner.classList.contains('paused');
    chrome.runtime.sendMessage({ type: paused ? 'RESUME_REQUESTED' : 'PAUSE_REQUESTED' }).catch(() => {});
  });

  function shadowRoots() {
    const found = [];
    const walk = (root) => {
      for (const el of root.querySelectorAll('*')) {
        if (!el.shadowRoot) continue;
        found.push(el.shadowRoot);
        walk(el.shadowRoot);
      }
    };
    walk(document);
    return found;
  }

  function labelledText(el) {
    const ids = el.getAttribute('aria-labelledby');
    if (!ids) return '';
    const root = el.getRootNode();
    return ids
      .split(/\s+/)
      .map((id) => root.getElementById?.(id)?.textContent ?? '')
      .join(' ');
  }

  function accessibleText(el) {
    const parts = [
      el.textContent,
      el.getAttribute('aria-label'),
      el.getAttribute('title'),
      el.getAttribute('placeholder'),
      el.getAttribute('alt'),
      el.getAttribute('name'),
      labelledText(el)
    ];
    if (typeof el.value === 'string') parts.push(el.value);
    return parts.filter(Boolean).join(' ').replace(/\s+/g, ' ').trim().toLowerCase();
  }

  const HAS_TEXT = /:has-text\((?:"([^"]*)"|'([^']*)')\)\s*$/;

  function queryAll(selector) {
    const textMatch = HAS_TEXT.exec(selector);
    const base = textMatch ? selector.slice(0, textMatch.index) || '*' : selector;
    const wanted = textMatch ? (textMatch[1] ?? textMatch[2]).trim().toLowerCase() : null;

    const matching = (root) => {
      let found;
      try {
        found = root.querySelectorAll(base);
      } catch {
        throw new Error(`"${selector}" is not a valid selector`);
      }
      return wanted === null ? [...found] : [...found].filter((el) => accessibleText(el).includes(wanted));
    };

    const inDocument = matching(document);
    if (inDocument.length > 0) return inDocument;
    return shadowRoots().flatMap(matching);
  }

  function isVisible(el) {
    if (el.getClientRects().length === 0) return false;
    const style = getComputedStyle(el);
    return style.visibility !== 'hidden' && style.opacity !== '0';
  }

  function isDisabled(el) {
    if (el.disabled === true) return true;
    return el.closest('[aria-disabled="true"], fieldset[disabled]') !== null;
  }

  function covering(el) {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return null;
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    if (x < 0 || y < 0 || x > innerWidth || y > innerHeight) return null;

    const root = el.getRootNode();
    const top = (root.elementFromPoint ? root : document).elementFromPoint(x, y);
    if (!top || top === el || el.contains(top) || top.contains(el)) return null;
    return top;
  }

  function describe(el) {
    const id = el.id ? `#${el.id}` : '';
    const cls = typeof el.className === 'string' && el.className ? `.${el.className.trim().split(/\s+/)[0]}` : '';
    return `<${el.tagName.toLowerCase()}${id}${cls}>`;
  }

  function rank(el) {
    if (!isVisible(el)) return 1;
    if (isDisabled(el)) return 2;
    if (covering(el)) return 3;
    return 4;
  }

  function best(selector) {
    const candidates = queryAll(selector);
    let winner = null;
    let winningRank = 0;
    for (const el of candidates) {
      const score = rank(el);
      if (score <= winningRank) continue;
      winner = el;
      winningRank = score;
    }
    return { winner, winningRank, count: candidates.length };
  }

  function explain({ winner, winningRank, count }) {
    if (count === 0) return 'nothing on this page matches it';
    const subject = count === 1 ? describe(winner) : `the best of ${count} matches, ${describe(winner)},`;
    if (winningRank === 1) return `${subject} is not visible`;
    if (winningRank === 2) return `${subject} is disabled`;
    return `${subject} is covered by ${describe(covering(winner))}`;
  }

  function waitForActionable(selector, timeout) {
    const deadline = Date.now() + (timeout ?? DEFAULT_TIMEOUT);
    return new Promise((resolve, reject) => {
      const attempt = () => {
        const found = best(selector);
        if (found.winningRank === 4) return resolve(found.winner);
        if (Date.now() >= deadline) return reject(new Error(`timed out waiting for ${selector} — ${explain(found)}`));
        setTimeout(attempt, POLL_MS);
      };
      attempt();
    });
  }

  function fingerprint(el) {
    const parts = [location.href, String(scrollY)];
    if (!el.isConnected) return parts.concat('detached').join('|');
    return parts
      .concat([
        String(el.checked),
        String(el.value),
        String(el.className),
        String(el.disabled),
        el.getAttribute('aria-expanded') ?? '',
        el.getAttribute('aria-pressed') ?? '',
        el.getAttribute('aria-checked') ?? '',
        el.getAttribute('aria-selected') ?? ''
      ])
      .join('|');
  }

  // Biased toward "something happened": a false no-op makes the app re-run the
  // action, and re-running a submit is worse than missing a dead click.
  function observe(el, perform) {
    const before = fingerprint(el);
    return new Promise((resolve, reject) => {
      let settled = false;
      const finish = (changed) => {
        if (settled) return;
        settled = true;
        observer.disconnect();
        clearTimeout(timer);
        removeEventListener('pagehide', leaving);
        removeEventListener('beforeunload', leaving);
        resolve(changed);
      };

      // A navigating click tears down this script before the timer fires, so
      // without this the reply never arrives and the step looks indeterminate.
      const leaving = () => finish(true);
      const observer = new MutationObserver(() => finish(true));
      const timer = setTimeout(() => finish(fingerprint(el) !== before), SETTLE_MS);

      observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true });
      addEventListener('pagehide', leaving, { once: true });
      addEventListener('beforeunload', leaving, { once: true });

      try {
        perform();
      } catch (error) {
        settled = true;
        observer.disconnect();
        clearTimeout(timer);
        reject(error);
      }
    });
  }

  function isCommitting(el, step) {
    if (step.kind === 'type' && step.submit) return true;
    if (el.form && el.tagName === 'INPUT') return el.type === 'submit' || el.type === 'image';
    if (el.form && el.tagName === 'BUTTON' && el.type === 'submit') return true;
    return COMMIT_WORDS.test(accessibleText(el));
  }

  function scanSensitive() {
    for (const [selector, description] of SENSITIVE) {
      const found = queryAll(selector).find((el) => el.getClientRects().length > 0);
      if (found) return description;
    }
    return null;
  }

  function assertWritableTarget(el) {
    for (const [selector, description] of SENSITIVE_TARGET) {
      if (el.matches(selector)) {
        throw new Error(`refusing to write into ${description} — fill it in yourself, then run this again`);
      }
    }
  }

  // React tracks the previous value on the node and ignores a plain assignment;
  // execCommand is deprecated but still the only path emitting editor InputEvents.
  function setValue(el, value) {
    if (el.isContentEditable) {
      const range = document.createRange();
      range.selectNodeContents(el);
      const selection = getSelection();
      selection.removeAllRanges();
      selection.addRange(range);
      if (!document.execCommand('insertText', false, value)) throw new Error('could not type into this editor');
      return;
    }
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function press(el) {
    const opts = { bubbles: true, cancelable: true, view: window, composed: true };
    el.dispatchEvent(new PointerEvent('pointerdown', opts));
    el.dispatchEvent(new MouseEvent('mousedown', opts));
    el.focus({ preventScroll: true });
    el.dispatchEvent(new PointerEvent('pointerup', opts));
    el.dispatchEvent(new MouseEvent('mouseup', opts));
    el.dispatchEvent(new MouseEvent('click', opts));
  }

  function submitFrom(el) {
    const key = { bubbles: true, cancelable: true, key: 'Enter', code: 'Enter', keyCode: 13, which: 13 };
    el.dispatchEvent(new KeyboardEvent('keydown', key));
    el.dispatchEvent(new KeyboardEvent('keyup', key));
    if (el.form) el.form.requestSubmit();
  }

  async function settle(step) {
    const el = await waitForActionable(step.selector, step.timeout);
    el.scrollIntoView({ block: 'center' });
    if (el.isConnected) return el;
    return waitForActionable(step.selector, step.timeout);
  }

  const ACTIONS = {
    async click(step) {
      const el = await settle(step);
      const committing = isCommitting(el, step);
      const changed = await observe(el, () => press(el));
      return { changed, committing };
    },

    async type(step) {
      const el = await settle(step);
      assertWritableTarget(el);
      const committing = isCommitting(el, step);
      const changed = await observe(el, () => {
        el.focus({ preventScroll: true });
        setValue(el, step.text);
        if (step.submit) submitFrom(el);
      });
      return { changed, committing };
    },

    async select(step) {
      const el = await settle(step);
      assertWritableTarget(el);
      const changed = await observe(el, () => {
        el.value = step.value;
        el.dispatchEvent(new Event('change', { bubbles: true }));
      });
      return { changed, committing: false };
    },

    async wait(step) {
      if (step.forSelector) {
        await waitForActionable(step.forSelector, 15000);
        return {};
      }
      await new Promise((resolve) => setTimeout(resolve, step.ms ?? 1000));
      return {};
    },

    async scroll(step) {
      if (step.selector) {
        const el = await waitForActionable(step.selector, step.timeout);
        el.scrollIntoView({ block: 'center' });
        return {};
      }
      scrollTo(0, step.to === 'top' ? 0 : document.body.scrollHeight);
      return {};
    },

    async extract(step) {
      const el = await waitForActionable(step.selector, step.timeout);
      return { value: el.innerText };
    }
  };

  function isRendered(el) {
    if (el.tagName === 'OPTION' || el.tagName === 'OPTGROUP') return true;
    return el.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true });
  }

  function appendRendered(target, children) {
    for (const child of children) {
      if (child.nodeType === Node.ELEMENT_NODE && !isRendered(child)) continue;
      target.append(cloneWithShadow(child));
    }
  }

  function cloneWithShadow(node) {
    const copy = node.cloneNode(false);
    if (node.shadowRoot) {
      const holder = document.createElement('shadow-root');
      appendRendered(holder, node.shadowRoot.childNodes);
      copy.append(holder);
    }
    appendRendered(copy, node.childNodes);
    return copy;
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === 'AGENT_STATE') {
      render(message);
      return;
    }

    if (message.type === 'SCAN') {
      sendResponse({ reason: scanSensitive() });
      return;
    }

    if (message.type === 'DOM') {
      sendResponse({ dom: cloneWithShadow(document.documentElement).outerHTML, title: document.title });
      return;
    }

    if (message.type === 'EXEC') {
      const run = ACTIONS[message.step.kind];
      if (!run) {
        sendResponse({ ok: false, error: `unsupported step kind "${message.step.kind}"` });
        return;
      }
      run(message.step).then(
        (result) => sendResponse({ ok: true, ...result }),
        (error) => sendResponse({ ok: false, error: error.message })
      );
      return true;
    }
  });

  chrome.runtime
    .sendMessage({ type: 'GET_STATE' })
    .then((state) => state && render(state))
    .catch(() => {});
})();
